# roblab3 detect human > 2023-05-25 12:02am
https://universe.roboflow.com/robotlab3/roblab3-detect-human

Provided by a Roboflow user
License: CC BY 4.0

